/*
  1 tab == 4 spaces!
*/

#ifndef CONSOLCLI_H
#define CONSOLCLI_H

extern char debugMsgDispFlag ;

void consolDebugCLIregister(void);
#endif

