/*
*/

#ifndef OUTEVENTCLI_H
#define OUTEVENTCLI_H

void OutEventCLIregister(void);

#endif

