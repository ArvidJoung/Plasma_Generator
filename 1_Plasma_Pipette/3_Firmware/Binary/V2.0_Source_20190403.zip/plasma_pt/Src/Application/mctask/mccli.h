/*
*/

#ifndef MCCLI_H
#define MCCLI_H

void mcCLIregister(void);
#endif

