/*
*/

#ifndef INEVENTCLI_H
#define INEVENTCLI_H

void InEventCLIregister(void);

#endif

